package com.hospital.gui;

import com.hospital.database.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class AddPatientForm extends JFrame {
    private JTextField nameField, ageField, contactField;
    private JTextArea addressArea;
    private JComboBox<String> genderBox;

    public AddPatientForm() {
        setTitle("Add Patient");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(6, 2));

        add(new JLabel("Name:"));
        nameField = new JTextField();
        add(nameField);

        add(new JLabel("Age:"));
        ageField = new JTextField();
        add(ageField);

        add(new JLabel("Gender:"));
        genderBox = new JComboBox<>(new String[]{"Male", "Female"});
        add(genderBox);

        add(new JLabel("Contact:"));
        contactField = new JTextField();
        add(contactField);

        add(new JLabel("Address:"));
        addressArea = new JTextArea();
        add(new JScrollPane(addressArea));

        JButton addButton = new JButton("Add Patient");
        addButton.addActionListener(this::addPatient);
        add(addButton);
    }

    private void addPatient(ActionEvent e) {
        String name = nameField.getText();
        int age = Integer.parseInt(ageField.getText());
        String gender = genderBox.getSelectedItem().toString();
        String contact = contactField.getText();
        String address = addressArea.getText();

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO patients (name, age, gender, contact, address) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setInt(2, age);
            stmt.setString(3, gender);
            stmt.setString(4, contact);
            stmt.setString(5, address);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Patient added successfully!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AddPatientForm().setVisible(true));
    }
}
