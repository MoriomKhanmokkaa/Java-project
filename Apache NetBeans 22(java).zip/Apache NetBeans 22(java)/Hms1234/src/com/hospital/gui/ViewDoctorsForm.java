package com.hospital.gui;

import com.hospital.database.DBConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.ResultSet;

public class ViewDoctorsForm extends JFrame {
    private JTable doctorsTable;
    private DefaultTableModel tableModel;

    public ViewDoctorsForm() {
        setTitle("View Doctors");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null); // Center the window on the screen

        // Initialize table model and JTable
        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Specialization", "Contact"}, 0);
        doctorsTable = new JTable(tableModel);

        // Load doctors from the database
        loadDoctors();

        // Add table to a scroll pane
        add(new JScrollPane(doctorsTable), BorderLayout.CENTER);

        // Close button
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        add(closeButton, BorderLayout.SOUTH);
    }

    private void loadDoctors() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT id, name, specialization, contact FROM doctors";
            ResultSet rs = conn.createStatement().executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String specialization = rs.getString("specialization");
                String contact = rs.getString("contact");

                tableModel.addRow(new Object[]{id, name, specialization, contact});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading doctors: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ViewDoctorsForm().setVisible(true));
    }
}
