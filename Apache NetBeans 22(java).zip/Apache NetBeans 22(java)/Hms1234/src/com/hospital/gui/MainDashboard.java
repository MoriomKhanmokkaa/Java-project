package com.hospital.gui;

import javax.swing.*;

public class MainDashboard extends JFrame {
    public MainDashboard() {
        setTitle("Hospital Management System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        JButton patientButton = new JButton("Manage Patients");
        patientButton.addActionListener(e -> new AddPatientForm().setVisible(true));
        add(patientButton);

        JButton doctorButton = new JButton("Manage Doctors");
        doctorButton.addActionListener(e -> new AddDoctorForm().setVisible(true));
        add(doctorButton);

        JButton appointmentButton = new JButton("Schedule Appointments");
        appointmentButton.addActionListener(e -> new ScheduleAppointmentForm().setVisible(true));
        add(appointmentButton);

        JButton viewAppointmentsButton = new JButton("View Appointments");
        viewAppointmentsButton.addActionListener(e -> new ViewAppointmentsForm().setVisible(true));
        add(viewAppointmentsButton);

        JButton viewPatientsButton = new JButton("View Patients");
        viewPatientsButton.addActionListener(e -> new ViewPatientsForm().setVisible(true));
        add(viewPatientsButton);

        JButton viewDoctorsButton = new JButton("View Doctors");
        viewDoctorsButton.addActionListener(e -> new ViewDoctorsForm().setVisible(true));
        add(viewDoctorsButton);

        setLocationRelativeTo(null); // Center the window on the screen
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Show login dialog
            LoginDialog loginDialog = new LoginDialog(null);
            loginDialog.setVisible(true);

            if (loginDialog.isAuthenticated()) {
                // Launch the dashboard if login is successful
                new MainDashboard().setVisible(true);
            } else {
                System.exit(0); // Exit if login fails or is canceled
            }
        });
    }
}
