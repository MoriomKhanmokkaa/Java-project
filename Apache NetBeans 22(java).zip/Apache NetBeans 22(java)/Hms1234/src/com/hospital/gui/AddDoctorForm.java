package com.hospital.gui;

import com.hospital.database.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class AddDoctorForm extends JFrame {
    private JTextField nameField, specializationField, contactField;

    public AddDoctorForm() {
        // Set title and size
        setTitle("Add Doctor");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(4, 2, 10, 10));
        setLocationRelativeTo(null); // Center the window on the screen

        // Name Field
        add(new JLabel("Name:"));
        nameField = new JTextField();
        add(nameField);

        // Specialization Field
        add(new JLabel("Specialization:"));
        specializationField = new JTextField();
        add(specializationField);

        // Contact Field
        add(new JLabel("Contact:"));
        contactField = new JTextField();
        add(contactField);

        // Add Doctor Button
        JButton addButton = new JButton("Add Doctor");
        addButton.addActionListener(this::addDoctor);
        add(addButton);

        // Cancel Button
        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> dispose());
        add(cancelButton);
    }

    private void addDoctor(ActionEvent e) {
        String name = nameField.getText();
        String specialization = specializationField.getText();
        String contact = contactField.getText();

        if (name.isEmpty() || specialization.isEmpty() || contact.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO doctors (name, specialization, contact) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, specialization);
            stmt.setString(3, contact);

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Doctor added successfully!");
                clearFields();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        nameField.setText("");
        specializationField.setText("");
        contactField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AddDoctorForm().setVisible(true));
    }
}
