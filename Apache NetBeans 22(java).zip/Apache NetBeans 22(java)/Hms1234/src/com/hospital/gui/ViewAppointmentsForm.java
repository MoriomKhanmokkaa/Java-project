package com.hospital.gui;

import com.hospital.database.DBConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.ResultSet;

public class ViewAppointmentsForm extends JFrame {
    private JTable appointmentsTable;
    private DefaultTableModel tableModel;

    public ViewAppointmentsForm() {
        // Set title and size
        setTitle("View Appointments");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null); // Center the window on the screen

        // Table model and JTable
        tableModel = new DefaultTableModel(new String[]{"Appointment ID", "Patient", "Doctor", "Date", "Description"}, 0);
        appointmentsTable = new JTable(tableModel);

        // Load appointments from the database
        loadAppointments();

        // Add table to a scroll pane
        add(new JScrollPane(appointmentsTable), BorderLayout.CENTER);

        // Close button
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        add(closeButton, BorderLayout.SOUTH);
    }

    private void loadAppointments() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT a.id, p.name AS patient_name, d.name AS doctor_name, a.appointment_date, a.description " +
                         "FROM appointments a " +
                         "JOIN patients p ON a.patient_id = p.id " +
                         "JOIN doctors d ON a.doctor_id = d.id";
            ResultSet rs = conn.createStatement().executeQuery(sql);

            while (rs.next()) {
                int appointmentId = rs.getInt("id");
                String patientName = rs.getString("patient_name");
                String doctorName = rs.getString("doctor_name");
                String appointmentDate = rs.getString("appointment_date");
                String description = rs.getString("description");

                tableModel.addRow(new Object[]{appointmentId, patientName, doctorName, appointmentDate, description});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading appointments: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ViewAppointmentsForm().setVisible(true));
    }
}
