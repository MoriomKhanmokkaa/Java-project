package com.hospital.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class LoginDialog extends JDialog {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private boolean authenticated;

    public LoginDialog(JFrame parent) {
        super(parent, "Login", true);
        setSize(300, 200);
        setLayout(new GridLayout(3, 2, 10, 10));
        setLocationRelativeTo(parent);

        add(new JLabel("Username:"));
        usernameField = new JTextField();
        add(usernameField);

        add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(this::authenticate);
        add(loginButton);

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> {
            authenticated = false;
            dispose();
        });
        add(cancelButton);
    }

    private void authenticate(ActionEvent e) {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        // Hardcoded credentials for demonstration purposes
        if ("admin".equals(username) && "password123".equals(password)) {
            authenticated = true;
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials. Please try again.",
                    "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isAuthenticated() {
        return authenticated;
    }

    public static void main(String[] args) {
        JFrame dummyFrame = new JFrame(); // For testing
        LoginDialog loginDialog = new LoginDialog(dummyFrame);
        loginDialog.setVisible(true);
        if (loginDialog.isAuthenticated()) {
            System.out.println("Login successful!");
        } else {
            System.out.println("Login cancelled or failed.");
        }
    }
}
