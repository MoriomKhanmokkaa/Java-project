package com.hospital.gui;

import com.hospital.database.DBConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.ResultSet;

public class ViewPatientsForm extends JFrame {
    private JTable patientsTable;
    private DefaultTableModel tableModel;

    public ViewPatientsForm() {
        setTitle("View Patients");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null); // Center the window on the screen

        // Initialize table model and JTable
        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Age", "Gender", "Contact", "Address"}, 0);
        patientsTable = new JTable(tableModel);

        // Load patients from the database
        loadPatients();

        // Add table to a scroll pane
        add(new JScrollPane(patientsTable), BorderLayout.CENTER);

        // Close button
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        add(closeButton, BorderLayout.SOUTH);
    }

    private void loadPatients() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT id, name, age, gender, contact, address FROM patients";
            ResultSet rs = conn.createStatement().executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String gender = rs.getString("gender");
                String contact = rs.getString("contact");
                String address = rs.getString("address");

                tableModel.addRow(new Object[]{id, name, age, gender, contact, address});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading patients: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ViewPatientsForm().setVisible(true));
    }
}
