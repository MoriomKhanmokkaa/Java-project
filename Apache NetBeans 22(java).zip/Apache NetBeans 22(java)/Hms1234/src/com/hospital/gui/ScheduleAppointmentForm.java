package com.hospital.gui;

import com.hospital.database.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ScheduleAppointmentForm extends JFrame {
    private JComboBox<String> patientComboBox, doctorComboBox;
    private JTextField dateField;
    private JTextArea descriptionArea;

    public ScheduleAppointmentForm() {
        // Set title and size
        setTitle("Schedule Appointment");
        setSize(500, 350);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(5, 2, 10, 10));
        setLocationRelativeTo(null); // Center the window on the screen

        // Patient Dropdown
        add(new JLabel("Select Patient:"));
        patientComboBox = new JComboBox<>();
        loadPatients();
        add(patientComboBox);

        // Doctor Dropdown
        add(new JLabel("Select Doctor:"));
        doctorComboBox = new JComboBox<>();
        loadDoctors();
        add(doctorComboBox);

        // Date Field
        add(new JLabel("Appointment Date (YYYY-MM-DD):"));
        dateField = new JTextField();
        add(dateField);

        // Description Area
        add(new JLabel("Description:"));
        descriptionArea = new JTextArea();
        add(new JScrollPane(descriptionArea));

        // Schedule Button
        JButton scheduleButton = new JButton("Schedule Appointment");
        scheduleButton.addActionListener(this::scheduleAppointment);
        add(scheduleButton);

        // Cancel Button
        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> dispose());
        add(cancelButton);
    }

    private void loadPatients() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT id, name FROM patients";
            ResultSet rs = conn.createStatement().executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                patientComboBox.addItem(id + " - " + name);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading patients: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadDoctors() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT id, name FROM doctors";
            ResultSet rs = conn.createStatement().executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                doctorComboBox.addItem(id + " - " +name);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading doctors: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void scheduleAppointment(ActionEvent event) {
        try (Connection conn = DBConnection.getConnection()) {
            // Get selected patient and doctor
            String selectedPatient = (String) patientComboBox.getSelectedItem();
            String selectedDoctor = (String) doctorComboBox.getSelectedItem();

            if (selectedPatient == null || selectedDoctor == null || dateField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields.",
                        "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Extract patient and doctor IDs from selections
            int patientId = Integer.parseInt(selectedPatient.split(" - ")[0]);
            int doctorId = Integer.parseInt(selectedDoctor.split(" - ")[0]);

            String appointmentDate = dateField.getText();
            String description = descriptionArea.getText();

            // Insert the appointment into the database
            String sql = "INSERT INTO appointments (patient_id, doctor_id, appointment_date, description) " +
                         "VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, patientId);
            pstmt.setInt(2, doctorId);
            pstmt.setString(3, appointmentDate);
            pstmt.setString(4, description);

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Appointment scheduled successfully!",
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                dispose(); // Close the form
            } else {
                JOptionPane.showMessageDialog(this, "Failed to schedule appointment.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error scheduling appointment: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ScheduleAppointmentForm().setVisible(true));
    }
}
